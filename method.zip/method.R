#In this script we demonstrate the method to generate training and testing data;
#The method to generate sequence-derived features and genome-drived features 
#The method for the features selection

require(GenomicAlignments)
require(Rsamtools)
require(BiocParallel)
require(BSgenome)
require(BSgenome.Hsapiens.UCSC.hg19)
library(TxDb.Hsapiens.UCSC.hg19.knownGene)

#To generate Training Data and select Independent testing data
#if we used base-resultion HEK293_abacm as indepednent testing data

IndependentTesting <- "HEK293_abacm"
Base_relsotionSite.csv <- read.csv("SingleNucleotideReselutionData.csv")
IndependentTesting.index <- which(colnames(Base_relsotionSite.csv)==IndependentTesting)
IndependentTesting.row <- which(Base_relsotionSite.csv[,IndependentTesting.index]==1)
IndependentTesting.data <- Base_relsotionSite.csv[IndependentTesting.row,c(2:6)]

Training.data.index.col <- c(1:12)[-IndependentTesting.index][-c(1:6)]
Training.data <- Base_relsotionSite.csv[,c(Training.data.index.col)]
Training.data.index.row <- apply(Training.data, 1, sum)
Training.MoreThanTwoRecorded <- which(Training.data.index.row>1)


GR <- function(Data){
  data <- GRanges(seqnames = Data$chromsome,
                  ranges = IRanges(start = Data$modEnd,width = 1)
                  ,strand = Data$strand)
  return(data)
}

Training.GR <- GR(Base_relsotionSite.csv[Training.MoreThanTwoRecorded,c(2:6)])
IndependentTesting.GR <- GR(IndependentTesting.data)

Training.GR.ConsensusM6A <- Training.GR[which(vcountPattern("RRACH",DNAStringSet(Views(Hsapiens, Training.GR+2)),fixed = F)==1)]
IndependentTesting.GR.ConsensusM6A <- IndependentTesting.GR[which(vcountPattern("RRACH",DNAStringSet(Views(Hsapiens, IndependentTesting.GR+2)),fixed = F)==1)]

#Rondom select non-methyalted data with consensus m6A motif  
MotifInFullTranscript <- vmatchPattern("RRACH",Hsapiens,fixed = F)
MotifInFullTranscript <- MotifInFullTranscript[-which(vcountPattern("NNNNNNN",DNAStringSet(Views(Hsapiens, MotifInFullTranscript+2)),fixed = F)==1)]

txdb <- TxDb.Hsapiens.UCSC.hg19.knownGene

Training.FullTranscript.geneInformation <- subsetByOverlaps(genes(txdb),Training.GR.ConsensusM6A)
IndependentTesting.GR.ConsensusM6A.geneInformation <- subsetByOverlaps(genes(txdb),IndependentTesting.GR.ConsensusM6A)

geneInformation <- c(Training.FullTranscript.geneInformation,IndependentTesting.GR.ConsensusM6A.geneInformation)

NotMethylated.gene <- subsetByOverlaps(MotifInFullTranscript,geneInformation)
NotMethylated.motif <- Not_methylated_gene[!NotMethylated.gene %over% c(Training.GR.ConsensusM6A,IndependentTesting.GR.ConsensusM6A )]


Training.length <- length(Training.GR)
IndependentTesting.length <- length(IndependentTesting.GR)

NegativeSample <- NotMethylated.motif[sample.int(length(Not_methylated_gene),Training.length*10+IndependentTesting.length *10 )]

Training.NegativeSample <- list()
IndependentTesting.NegativeSample <- list()

for(i in 1:10){
  Training.NegativeSample[[i]] <- NegativeSample[((i-1)*Training.length+1),i*Training.length]
}

for(i in 1:10){
  IndependentTesting.NegativeSample[[i]] <- NegativeSample[((i-1)*Training.length+1+10*Training.length),i*Training.length+Training.length*10]
}

#sequence-derived features generation
##To generate predictior trained by the 1:1 postive site with negative sites 

Training.predictor.data <- c(Training.data,Training.NegativeSample[[1]]-2)

alter_chemical_NF <- function(Data){
  A <- c(1,1,1)%>%matrix(nrow=1)
  C <- c(0,1,0)%>%matrix(nrow=1)
  G <- c(1,0,0)%>%matrix(nrow=1)
  T <- c(0,0,1)%>%matrix(nrow=1)
  N <- c(0,0,0,0)%>%matrix(nrow=1)
  binary_matrix <- matrix(NA,nrow = 1, ncol = 1)
  for(i in 1:length(Data)){
    if (Data[i]=="A"){
      binary_matrix <- cbind(binary_matrix,A)
      TTAppear <- length(which(Data[1:i]=="A"))
      Nucleotide_frequency <- (TTAppear/i) 
      binary_matrix <- cbind(binary_matrix,Nucleotide_frequency)
    }else if (Data[i]=="C"){
      binary_matrix <- cbind(binary_matrix,C)
      TTAppear <- length(which(Data[1:i]=="C"))
      Nucleotide_frequency <- (TTAppear/i) 
      binary_matrix <- cbind(binary_matrix,Nucleotide_frequency)
    }else if (Data[i]=="G"){
      binary_matrix <- cbind(binary_matrix,G)
      TTAppear <- length(which(Data[1:i]=="G"))
      Nucleotide_frequency <- (TTAppear/i) 
      binary_matrix <- cbind(binary_matrix,Nucleotide_frequency)
    }else if (Data[i]=="T"){
      binary_matrix <- cbind(binary_matrix,T)
      TTAppear <- length(which(Data[1:i]=="T"))
      Nucleotide_frequency <- (TTAppear/i) 
      binary_matrix <- cbind(binary_matrix,Nucleotide_frequency)
    }else{
      binary_matrix <- cbind(binary_matrix,N)
    }
  }
  binary_matrix <- binary_matrix[,-1]
  return(binary_matrix)
}

sequenceDerived <- function(data){
  motiftest <- motifSplit(data)
  motifBinary <- matrix(NA,nrow = 1, ncol = 4*length(motiftest[[1]]))
  for (i in 1:length(motiftest)){
    motifstr <- alter_chemical_NF(unlist(motiftest[[i]]))%>%matrix(nrow = 1)
    motifBinary <- rbind(motifBinary,motifstr)
  }
  motifBinary <- motifBinary[-1,]
  return(motifBinary)
}


Training.predictor.Seqdata <- as.character(DNAStringSet(Views(Hsapiens,Training.predictor.data+20)))

#genome-derived features generation
#we build a package for the genome-derived features 
devtools::install_github("ZhenWei10/m6ALogisticModel")

library(m6ALogisticModel)
library(SummarizedExperiment)
library(TxDb.Hsapiens.UCSC.hg19.knownGene)
library(BSgenome.Hsapiens.UCSC.hg19)
library(fitCons.UCSC.hg19)
library(phastCons100way.UCSC.hg19)

matureSE <- SummarizedExperiment()
rowRanges(matureSE) <- Training.predictor.data


Additional_features_hg19 = list(
  HNRNPC_eCLIP = eCLIP_HNRNPC_gr,
  YTHDC1_TREW = YTHDC1_TREW_gr,
  YTHDF1_TREW = YTHDF1_TREW_gr,
  YTHDF2_TREW = YTHDF2_TREW_gr,
  miR_targeted_genes = miR_targeted_genes_grl,
  TargetScan = TargetScan_hg19_gr,
  Verified_miRtargets = verified_targets_gr,
  METTL3_TREW = METTL3_TREW,
  METTL14_TREW = METTL14_TREW,
  WTAP_TREW = WTAP_TREW,
  METTL16_CLIP = METTL16_CLIP,
  ALKBH5_PARCLIP = ALKBH5_PARCLIP,
  FTO_CLIP = FTO_CLIP,
  FTO_eCLIP = FTO_eCLIP
)

matureFE <- predictors_annot(se = matureSE,
                             txdb = TxDb.Hsapiens.UCSC.hg19.knownGene,
                             bsgnm = Hsapiens,
                             fc = fitCons.UCSC.hg19,
                             pc = phastCons100way.UCSC.hg19,
                             struct_hybridize = Struc_hg19,
                             feature_lst = Additional_features_hg19,
                             hk_genes_list = HK_hg19_eids,
                             genes_ambiguity_method = "average")

Training.predictor.Gendata<- mcols(matureFE)

#Feature selection
##Importance generation
training <- Training.predictor.Gendata %>% as.data.frame
label_train <- c(rep("motif",Training.length),rep("non ",Training.length))
label_train <- factor(label_train,labels=c("motif","non"))
training$class <- label_train 

fitControl <- trainControl(method = "cv",
                           ## 10-fold CV...
                           number = 10)

set.seed(825)
Laplacian <- train(class ~ ., data = training, 
                   method = "svmRadial", 
                   preProc = c("center", "scale"),
                   trControl = fitControl)

importance <- varImp(Laplacian,scale="FALSE")  

##Perforamce based on the importance 
bio_length <- ncol(Training.predictor.Gendata)
PerforamceImportance <- NA

Training.length.train <- round(Training.length/5)*4
Training.length.test <- Training.length-Training.length.train 

label_train <- c(rep("motif",Training.length.train),rep("non",Training.length.train))
label_train <- factor(label_train,labels=c("motif","non"))
testlabel <- c(rep(1,Training.length.test),rep(0,Training.length.test))
for (i in 1:bio_length){
  BIOmotifvsnontrain <- rbind(Training.predictor.Gendata[1:Training.length.train,],Training.predictor.Gendata[(length.train+1):(length.train+Training.length.train),])[,which(rank(importance$importance$motif)> (bio_length-i))]%>%as.matrix()
  print(i)
  BIOmotifvsnon_SVM <- svm(BIOmotifvsnontrain,label_train,cross=5, probability = TRUE)
  
  
  BIOmotifvsnontest <- rbind(Training.predictor.Gendata[(Training.length.train+1):(Training.length.train+Training.length.test),],Training.predictor.Gendata[(length.train+1+Training.length.train):(2*Training.length),])[,which(rank(importance$importance$motif)> (bio_length-i))]%>%as.matrix()
  
  pred <- predict(BIOmotifvsnon_SVM,BIOmotifvsnontest, probability = TRUE)
  motif <- attr(pred, 'probabilities')[,1]
  testppred <- prediction(motif,testlabel)
  testpppred_auc <- performance(testppred,"auc")
  
  auc_vector <- c(auc_vector,attr(testpppred_auc,"y.values")[[1]]) 
}